void semaforo_setup(void);
void semaforo_loop(void);

